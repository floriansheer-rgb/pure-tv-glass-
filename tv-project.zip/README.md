# PURE TV GLASS

Lanceur Android TV natif (Kotlin, sans dépendance externe, sans publicité).

## Compilation (sans ordinateur, depuis un iPhone)
1. Créer un dépôt GitHub, y envoyer `tv-project.zip`.
2. Créer le fichier `.github/workflows/build.yml` avec le contenu de `tv-build.yml`.
3. L'onglet Actions compile ; l'APK est dans Releases.

## Fond d'écran (optionnel)
Envoyer une image nommée `wallpaper.jpg` (ou `.png`, `.webp`) à la racine du dépôt GitHub : elle est intégrée automatiquement à la compilation et remplace les vagues.

## Installation sur la télé
Télécharger `app-debug.apk` avec l'application « Downloader » (Android TV), autoriser les sources inconnues, installer.

## Limites connues (non vérifiées sur une vraie télé)
- Le projet n'a pas été compilé ni testé par son auteur : une erreur de compilation reste possible.
- Selon la télé, le bouton Accueil peut continuer d'ouvrir l'écran d'origine.
- « Éteindre » ne fonctionne en général pas depuis un lanceur.
- « TV en direct » et « Lecteur USB » dépendent des applications présentes sur la télé.
