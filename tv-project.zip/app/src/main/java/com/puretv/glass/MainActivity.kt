package com.puretv.glass

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private class AppEntry(val pkg: String, val label: String, val intent: Intent, val icon: Drawable)

    private lateinit var prefs: SharedPreferences
    private lateinit var content: FrameLayout
    private val menuViews = ArrayList<LinearLayout>()
    private var section = 0
    private val matchParent = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val defaults = arrayOf(
        "com.netflix.ninja",
        "com.google.android.youtube.tv",
        "com.plexapp.android",
        "com.disney.disneyplus",
        "com.amazon.amazonvideo.livingroom",
        "tv.molotov.app",
        "com.spotify.tv.android"
    )

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun box(fill: Int, stroke: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(radius).toFloat()
        if (stroke != 0) g.setStroke(dp(2), stroke)
        return g
    }

    private fun focusBg(fill: Int, stroke: Int, focusFill: Int, focusStroke: Int, radius: Int): StateListDrawable {
        val s = StateListDrawable()
        s.addState(intArrayOf(android.R.attr.state_focused), box(focusFill, focusStroke, radius))
        s.addState(intArrayOf(), box(fill, stroke, radius))
        return s
    }

    private fun menuBg(selected: Boolean): StateListDrawable {
        val fill = if (selected) 0x553B82F6 else 0
        val stroke = if (selected) 0xCC60A5FA.toInt() else 0
        return focusBg(fill, stroke, 0x33FFFFFF, 0x99FFFFFF.toInt(), 26)
    }

    private fun focusScale(v: View, scale: Float) {
        v.setOnFocusChangeListener { view, hasFocus ->
            val s = if (hasFocus) scale else 1f
            view.animate().scaleX(s).scaleY(s).setDuration(110).start()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("pure", Context.MODE_PRIVATE)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)

        val dm = resources.displayMetrics
        val sw = dm.widthPixels
        val sh = dm.heightPixels
        val root = FrameLayout(this)
        root.addView(WaveView(this), FrameLayout.LayoutParams(matchParent, matchParent))

        val timeBox = LinearLayout(this)
        timeBox.orientation = LinearLayout.VERTICAL
        val clock = TextClock(this)
        clock.format24Hour = "HH:mm"
        clock.format12Hour = "HH:mm"
        clock.setTextColor(Color.WHITE)
        clock.textSize = 54f
        val date = TextClock(this)
        date.format24Hour = "EEE d MMM yyyy"
        date.format12Hour = "EEE d MMM yyyy"
        date.setTextColor(0xFFD3DBF2.toInt())
        date.textSize = 18f
        timeBox.addView(clock)
        timeBox.addView(date)
        val tlp = FrameLayout.LayoutParams(wrap, wrap)
        tlp.leftMargin = dp(48)
        tlp.topMargin = dp(30)
        root.addView(timeBox, tlp)

        val right = LinearLayout(this)
        right.orientation = LinearLayout.HORIZONTAL
        right.gravity = Gravity.CENTER_VERTICAL
        val wifi = ImageView(this)
        wifi.setImageResource(R.drawable.ic_wifi)
        wifi.setColorFilter(Color.WHITE)
        right.addView(wifi, LinearLayout.LayoutParams(dp(28), dp(28)))
        val sep = View(this)
        sep.setBackgroundColor(0x55FFFFFF)
        val slp = LinearLayout.LayoutParams(dp(1), dp(24))
        slp.leftMargin = dp(18)
        slp.rightMargin = dp(18)
        right.addView(sep, slp)
        val gear = ImageView(this)
        gear.setImageResource(R.drawable.ic_settings)
        gear.setColorFilter(Color.WHITE)
        gear.setPadding(dp(6), dp(6), dp(6), dp(6))
        gear.isFocusable = true
        gear.isClickable = true
        gear.background = focusBg(0, 0, 0x33FFFFFF, 0x99FFFFFF.toInt(), 20)
        focusScale(gear, 1.1f)
        gear.setOnClickListener { openSettings() }
        right.addView(gear, LinearLayout.LayoutParams(dp(40), dp(40)))
        val rlp = FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.END)
        rlp.topMargin = dp(36)
        rlp.rightMargin = dp(48)
        root.addView(right, rlp)

        val menu = LinearLayout(this)
        menu.orientation = LinearLayout.VERTICAL
        menu.setPadding(dp(14), dp(14), dp(14), dp(6))
        menu.background = box(0x1AFFFFFF, 0x22FFFFFF, 28)
        val labels = arrayOf("Accueil", "Applications", "Favoris", "Paramètres", "Éteindre")
        val icons = intArrayOf(R.drawable.ic_home, R.drawable.ic_apps, R.drawable.ic_play, R.drawable.ic_settings, R.drawable.ic_power)
        for (i in labels.indices) {
            val m = menuItem(i, labels[i], icons[i])
            menuViews.add(m)
            val lp = LinearLayout.LayoutParams(matchParent, dp(54))
            lp.bottomMargin = dp(8)
            menu.addView(m, lp)
        }
        val mlp = FrameLayout.LayoutParams((sw * 0.18f).toInt(), wrap)
        mlp.leftMargin = dp(32)
        mlp.topMargin = (sh * 0.27f).toInt()
        root.addView(menu, mlp)

        content = FrameLayout(this)
        content.clipChildren = false
        val clp = FrameLayout.LayoutParams(matchParent, matchParent)
        clp.leftMargin = (sw * 0.22f).toInt()
        clp.topMargin = (sh * 0.22f).toInt()
        clp.rightMargin = dp(24)
        root.addView(content, clp)

        setContentView(root)
        show(0)
        menuViews[0].requestFocus()
    }

    private fun menuItem(idx: Int, label: String, icon: Int): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(16), 0, dp(16), 0)
        row.isFocusable = true
        row.isClickable = true
        val iv = ImageView(this)
        iv.setImageResource(icon)
        iv.setColorFilter(Color.WHITE)
        row.addView(iv, LinearLayout.LayoutParams(dp(26), dp(26)))
        val tv = TextView(this)
        tv.text = label
        tv.setTextColor(Color.WHITE)
        tv.textSize = 18f
        val tlp = LinearLayout.LayoutParams(wrap, wrap)
        tlp.leftMargin = dp(16)
        row.addView(tv, tlp)
        focusScale(row, 1.04f)
        row.setOnClickListener { onMenu(idx) }
        return row
    }

    private fun onMenu(idx: Int) {
        when (idx) {
            0, 1, 2 -> show(idx)
            3 -> openSettings()
            else -> powerOff()
        }
    }

    private fun show(i: Int) {
        section = i
        for (k in menuViews.indices) menuViews[k].background = menuBg(k == i)
        content.removeAllViews()
        val v = when (i) {
            0 -> buildHome()
            1 -> buildGrid(true)
            else -> buildGrid(false)
        }
        content.addView(v, FrameLayout.LayoutParams(matchParent, matchParent))
    }

    private fun title(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 24f
        t.setPadding(dp(6), 0, 0, dp(8))
        return t
    }

    private fun hint(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(0xFFA9B6D6.toInt())
        t.textSize = 14f
        t.setPadding(dp(6), 0, 0, dp(10))
        return t
    }

    private fun buildHome(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.clipChildren = false
        col.addView(title("Mes applications"))
        val favs = favorites()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.clipChildren = false
        for (e in favs) row.addView(appTile(e, 108))
        if (favs.isEmpty()) row.addView(hint("Aucune application favorite. Choisis « Ajouter » ci-dessous."))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.isFocusable = false
        hs.clipToPadding = false
        hs.clipChildren = false
        hs.setPadding(0, dp(6), 0, dp(10))
        hs.addView(row)
        col.addView(hs)

        val t2 = title("Raccourcis")
        t2.setPadding(dp(6), dp(24), 0, dp(8))
        col.addView(t2)
        val sc = LinearLayout(this)
        sc.orientation = LinearLayout.HORIZONTAL
        sc.clipChildren = false
        sc.addView(shortcut("TV en direct", R.drawable.ic_tv) { openLiveTv() }, shortcutParams())
        sc.addView(shortcut("Lecteur USB", R.drawable.ic_usb) { openFiles() }, shortcutParams())
        sc.addView(shortcut("Mes fichiers", R.drawable.ic_folder) { openFiles() }, shortcutParams())
        sc.addView(shortcut("Ajouter", R.drawable.ic_add) {
            show(1)
            toast("Maintiens OK sur une application pour l’ajouter aux favoris")
        }, shortcutParams())
        col.addView(sc)
        return col
    }

    private fun shortcutParams(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(dp(140), dp(108))
        lp.rightMargin = dp(18)
        lp.leftMargin = dp(6)
        return lp
    }

    private fun buildGrid(all: Boolean): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(title(if (all) "Applications" else "Favoris"))
        col.addView(hint("Maintiens OK sur une application pour l’ajouter ou la retirer des favoris."))
        val apps = if (all) installedApps() else favorites()
        if (apps.isEmpty()) {
            col.addView(hint("Aucune application favorite pour l’instant."))
            return col
        }
        val grid = GridLayout(this)
        grid.columnCount = 6
        grid.clipChildren = false
        for (e in apps) grid.addView(appTile(e, 88))
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.isFocusable = false
        sv.clipToPadding = false
        sv.setPadding(dp(6), dp(10), dp(6), dp(30))
        sv.addView(grid)
        col.addView(sv, LinearLayout.LayoutParams(matchParent, matchParent))
        return col
    }

    private fun appTile(e: AppEntry, size: Int): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.setPadding(dp(10), dp(10), dp(10), dp(8))
        c.isFocusable = true
        c.isClickable = true
        c.isLongClickable = true
        c.background = focusBg(0, 0, 0x22FFFFFF, 0xAAFFFFFF.toInt(), 22)
        val iv = ImageView(this)
        iv.setImageDrawable(e.icon)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.clipToOutline = true
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(20).toFloat())
            }
        }
        c.addView(iv, LinearLayout.LayoutParams(dp(size), dp(size)))
        val tv = TextView(this)
        tv.text = e.label
        tv.setTextColor(Color.WHITE)
        tv.textSize = 14f
        tv.maxLines = 1
        tv.gravity = Gravity.CENTER
        tv.ellipsize = TextUtils.TruncateAt.END
        val lp = LinearLayout.LayoutParams(dp(size), wrap)
        lp.topMargin = dp(8)
        c.addView(tv, lp)
        focusScale(c, 1.08f)
        c.setOnClickListener { launch(e) }
        c.setOnLongClickListener {
            toggleFav(e)
            true
        }
        return c
    }

    private fun shortcut(label: String, icon: Int, action: () -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.isFocusable = true
        c.isClickable = true
        c.background = focusBg(0x22FFFFFF, 0x22FFFFFF, 0x44FFFFFF, 0xCCFFFFFF.toInt(), 20)
        val iv = ImageView(this)
        iv.setImageResource(icon)
        iv.setColorFilter(0xFFDDE6FF.toInt())
        c.addView(iv, LinearLayout.LayoutParams(dp(36), dp(36)))
        val tv = TextView(this)
        tv.text = label
        tv.setTextColor(Color.WHITE)
        tv.textSize = 14f
        tv.gravity = Gravity.CENTER
        val lp = LinearLayout.LayoutParams(wrap, wrap)
        lp.topMargin = dp(8)
        c.addView(tv, lp)
        focusScale(c, 1.08f)
        c.setOnClickListener { action() }
        return c
    }

    private fun installedApps(): List<AppEntry> {
        val pm = packageManager
        val seen = HashSet<String>()
        val out = ArrayList<AppEntry>()
        val cats = arrayOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
        for (cat in cats) {
            val q = Intent(Intent.ACTION_MAIN)
            q.addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val intent = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg) ?: continue
                out.add(AppEntry(pkg, ri.loadLabel(pm).toString(), intent, ri.loadIcon(pm)))
            }
        }
        out.sortBy { it.label.lowercase() }
        return out
    }

    private fun favoriteIds(): List<String> {
        val s = prefs.getString("favs", null) ?: return defaults.toList()
        return if (s.isEmpty()) emptyList() else s.split(",")
    }

    private fun favorites(): List<AppEntry> {
        val map = HashMap<String, AppEntry>()
        for (e in installedApps()) map[e.pkg] = e
        val out = ArrayList<AppEntry>()
        for (id in favoriteIds()) {
            val e = map[id]
            if (e != null) out.add(e)
        }
        return out
    }

    private fun toggleFav(e: AppEntry) {
        val ids = ArrayList<String>(favoriteIds())
        val msg: String
        if (ids.contains(e.pkg)) {
            ids.remove(e.pkg)
            msg = e.label + " retiré des favoris"
        } else {
            ids.add(e.pkg)
            msg = e.label + " ajouté aux favoris"
        }
        prefs.edit().putString("favs", ids.joinToString(",")).apply()
        toast(msg)
        if (section == 2) show(2)
    }

    private fun launch(e: AppEntry) {
        try {
            startActivity(e.intent)
        } catch (ex: Exception) {
            toast("Impossible d’ouvrir " + e.label)
        }
    }

    private fun openSettings() {
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        } catch (e: Exception) {
            toast("Réglages introuvables")
        }
    }

    private fun openFiles() {
        val pkgs = arrayOf(
            "com.android.documentsui",
            "com.google.android.documentsui",
            "com.mediatek.filemanager",
            "com.droidlogic.FileBrower",
            "com.estrongs.android.pop"
        )
        for (p in pkgs) {
            val i = packageManager.getLaunchIntentForPackage(p) ?: packageManager.getLeanbackLaunchIntentForPackage(p)
            if (i != null) {
                try {
                    startActivity(i)
                    return
                } catch (e: Exception) {
                }
            }
        }
        try {
            val g = Intent(Intent.ACTION_GET_CONTENT)
            g.type = "*/*"
            g.addCategory(Intent.CATEGORY_OPENABLE)
            startActivity(g)
        } catch (e: Exception) {
            toast("Aucun gestionnaire de fichiers trouvé")
        }
    }

    private fun openLiveTv() {
        val pkgs = arrayOf("com.google.android.tv", "com.droidlogic.tvinput", "com.android.tv")
        for (p in pkgs) {
            val i = packageManager.getLaunchIntentForPackage(p) ?: packageManager.getLeanbackLaunchIntentForPackage(p)
            if (i != null) {
                try {
                    startActivity(i)
                    return
                } catch (e: Exception) {
                }
            }
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("content://android.media.tv/channel")))
        } catch (e: Exception) {
            toast("Aucune application de TV en direct trouvée")
        }
    }

    private fun powerOff() {
        try {
            val i = Intent("com.android.internal.intent.action.REQUEST_SHUTDOWN")
            i.putExtra("android.intent.extra.KEY_CONFIRM", true)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("Extinction impossible depuis un lanceur : utilise la touche marche de la télécommande")
        }
    }

    override fun onBackPressed() {
        if (section != 0) show(0)
    }
}
