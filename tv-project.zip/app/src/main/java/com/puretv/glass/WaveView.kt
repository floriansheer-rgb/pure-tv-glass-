package com.puretv.glass

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.Shader
import android.view.View

class WaveView(context: Context) : View(context) {
    private var bmp: Bitmap? = null
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dst = Rect()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) {
            bmp = null
            return
        }
        val wp = loadWallpaper(w, h)
        bmp = if (wp != null) compose(wp, w, h) else render(w / 3, h / 3)
    }

    private fun loadWallpaper(w: Int, h: Int): Bitmap? {
        return try {
            val opts = BitmapFactory.Options()
            opts.inJustDecodeBounds = true
            context.assets.open("wallpaper.img").use { BitmapFactory.decodeStream(it, null, opts) }
            var s = 1
            while (opts.outWidth / (s * 2) >= w && opts.outHeight / (s * 2) >= h) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            context.assets.open("wallpaper.img").use { BitmapFactory.decodeStream(it, null, o2) }
        } catch (e: Exception) {
            null
        }
    }

    private fun compose(wp: Bitmap, w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val scale = maxOf(w.toFloat() / wp.width, h.toFloat() / wp.height)
        val sw = minOf((w / scale).toInt(), wp.width)
        val sh = minOf((h / scale).toInt(), wp.height)
        val sx = (wp.width - sw) / 2
        val sy = (wp.height - sh) / 2
        c.drawBitmap(wp, Rect(sx, sy, sx + sw, sy + sh), Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
        val p = Paint()
        p.shader = LinearGradient(0f, 0f, w.toFloat(), 0f, intArrayOf(0xCC02030A.toInt(), 0x4402030A, 0x00000000), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        p.shader = LinearGradient(0f, h.toFloat(), 0f, h * 0.6f, intArrayOf(0xAA02030A.toInt(), 0x00000000), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        wp.recycle()
        return b
    }

    private fun render(w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(maxOf(w, 2), maxOf(h, 2), Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val fw = b.width.toFloat()
        val fh = b.height.toFloat()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, fw, fh, intArrayOf(0xFF02030A.toInt(), 0xFF040A1C.toInt(), 0xFF071331.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, fw, fh, p)

        val w1 = Path()
        w1.moveTo(0f, fh * 0.92f)
        w1.cubicTo(fw * 0.25f, fh * 0.60f, fw * 0.55f, fh * 1.05f, fw, fh * 0.40f)
        w1.lineTo(fw, fh)
        w1.lineTo(0f, fh)
        w1.close()
        p.shader = LinearGradient(0f, fh, fw, 0f, intArrayOf(0x331D4ED8, 0x667C3AED, 0x331D4ED8), null, Shader.TileMode.CLAMP)
        c.drawPath(w1, p)

        val w2 = Path()
        w2.moveTo(0f, fh * 0.97f)
        w2.cubicTo(fw * 0.30f, fh * 0.75f, fw * 0.60f, fh * 1.00f, fw, fh * 0.62f)
        w2.lineTo(fw, fh)
        w2.lineTo(0f, fh)
        w2.close()
        p.shader = LinearGradient(0f, fh, fw, 0f, intArrayOf(0x2238BDF8, 0x557C3AED), null, Shader.TileMode.CLAMP)
        c.drawPath(w2, p)

        val w3 = Path()
        w3.moveTo(fw * 0.62f, 0f)
        w3.cubicTo(fw * 0.72f, fh * 0.35f, fw * 0.90f, fh * 0.15f, fw, fh * 0.55f)
        w3.lineTo(fw, 0f)
        w3.close()
        p.shader = LinearGradient(fw * 0.6f, 0f, fw, fh * 0.5f, intArrayOf(0x441D4ED8, 0x227C3AED), null, Shader.TileMode.CLAMP)
        c.drawPath(w3, p)
        return b
    }

    override fun onDraw(canvas: Canvas) {
        val b = bmp ?: return
        dst.set(0, 0, width, height)
        canvas.drawBitmap(b, null, dst, paint)
    }
}
